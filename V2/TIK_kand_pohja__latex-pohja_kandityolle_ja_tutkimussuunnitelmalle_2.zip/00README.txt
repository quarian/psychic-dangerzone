Tik.kand, Syksy 2011

LaTeX- ja BIBTeX-pohja


Käännä Linux-ympäristössä kirjoittamalla "make". 

Tiedostot UTF8-merkistökoodauksella. Voit muuttaa tarvittaessa 
"iconv -f ISO_8859-1 -t UTF8 file_Latin1.tex > file_UTF8.tex".

Voit tarkistaa syntaksia "lacheck main.tex".

Voit oikolukea Ubuntussa suomeksi "tmispell -dsuomi -t main.tex".

Windows-ympäristössä yksi mahdollinen ratkaisu on MiKTeX.org,
jonka päällä graafinen editori lED tai texlipse.sourceforge.net.

LaTeX-ohje:
http://www.ctan.org/tex-archive/info/lshort/finnish/lyhyt2e.pdf

Lisätietoja:
https://noppa.aalto.fi/noppa/kurssi/tik.kand

Kiitokset: tämä pohja lienee alunperin Sanna Suorannalta.
Luvun 3 teksti on suomen kielen lehtori Sanni Heinzmannilta.
Jukka Parviainen muokkasi tätä tammikuussa 2011 ja 
viimeksi syyskuussa 2011.


